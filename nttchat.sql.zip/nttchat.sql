-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 13, 2013 at 09:40 AM
-- Server version: 5.5.32
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `nttchat`
--
CREATE DATABASE IF NOT EXISTS `nttchat` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `nttchat`;

-- --------------------------------------------------------

--
-- Table structure for table `group_chat`
--

DROP TABLE IF EXISTS `group_chat`;
CREATE TABLE IF NOT EXISTS `group_chat` (
  `cgid` int(11) unsigned NOT NULL,
  `chat_group_name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `uid` int(11) unsigned NOT NULL COMMENT 'Author',
  `created` int(11) NOT NULL,
  PRIMARY KEY (`cgid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `group_chat_messages`
--

DROP TABLE IF EXISTS `group_chat_messages`;
CREATE TABLE IF NOT EXISTS `group_chat_messages` (
  `gmid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `from_id` int(11) NOT NULL,
  `cgroup_id` int(11) NOT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `created` int(11) unsigned NOT NULL,
  PRIMARY KEY (`gmid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `group_chat_users`
--

DROP TABLE IF EXISTS `group_chat_users`;
CREATE TABLE IF NOT EXISTS `group_chat_users` (
  `uid` int(11) NOT NULL,
  `cgid` int(11) NOT NULL,
  `joined` int(11) NOT NULL,
  PRIMARY KEY (`uid`,`cgid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `uid` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key: Unique user ID.',
  `username` varchar(60) NOT NULL DEFAULT '' COMMENT 'Unique user name.',
  `pass` varchar(128) NOT NULL DEFAULT '' COMMENT 'User’s password (hashed).',
  `first_name` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(1) DEFAULT '0' COMMENT 'Sex',
  `mail` varchar(320) DEFAULT '',
  `created` int(11) NOT NULL COMMENT 'Timestamp for when user was created.',
  `login` int(11) DEFAULT NULL COMMENT 'Timestamp for user’s last login.',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Whether the user is active(1) or blocked(0).',
  `avatar` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `role` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `name` (`username`),
  KEY `created` (`created`),
  KEY `mail` (`mail`(255))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Stores user data.' AUTO_INCREMENT=7 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `username`, `pass`, `first_name`, `last_name`, `gender`, `mail`, `created`, `login`, `status`, `avatar`, `role`) VALUES
(1, 'ttvnit', 'ad40d43372c7c1f8b3eaa5fce3057621', 'Tuan', 'Nguyen', 1, 'ttvnit@gmail.com', 1386817827, NULL, 0, 'pb010319.jpg', '{"bitMask":4,"title":"admin"}'),
(2, 'user', 'ad40d43372c7c1f8b3eaa5fce3057621', 'Thanh', 'Nam', 1, 'tuan1710@yahoo.com', 1383197935, NULL, 0, '', '{"bitMask":2,"title":"user"}'),
(4, 'tom', 'e10adc3949ba59abbe56e057f20f883e', 'thomas', 'Lei', 1, 'thomas@ozerside.com', 1385622860, NULL, 0, '', ''),
(5, 'ngocduyen', '25d55ad283aa400af464c76d713c07ad', 'Ngoc', 'Duyen', 0, 'duyennumberone@yahoo.com', 1386068984, NULL, 0, '', ''),
(6, 'test', 'ad40d43372c7c1f8b3eaa5fce3057621', '', '', 0, '', 1383068984, NULL, 0, '', '{"bitMask":4,"title":"admin"}');

-- --------------------------------------------------------

--
-- Table structure for table `user_friends`
--

DROP TABLE IF EXISTS `user_friends`;
CREATE TABLE IF NOT EXISTS `user_friends` (
  `uid` int(11) NOT NULL,
  `friend_uid` int(11) NOT NULL,
  `created` int(11) NOT NULL,
  `accepted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`,`friend_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_groups`
--

DROP TABLE IF EXISTS `user_groups`;
CREATE TABLE IF NOT EXISTS `user_groups` (
  `gid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `group_name` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `is_system` tinyint(1) NOT NULL,
  PRIMARY KEY (`gid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `user_groups`
--

INSERT INTO `user_groups` (`gid`, `uid`, `group_name`, `is_system`) VALUES
(1, 0, 'General', 0),
(2, 0, 'General', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_messages`
--

DROP TABLE IF EXISTS `user_messages`;
CREATE TABLE IF NOT EXISTS `user_messages` (
  `mid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `from_uid` int(11) NOT NULL,
  `to_uid` int(11) NOT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `created` int(11) NOT NULL,
  PRIMARY KEY (`mid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
